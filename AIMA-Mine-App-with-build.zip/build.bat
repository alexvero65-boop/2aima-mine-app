\
    @echo off
    REM Windows build script (PowerShell recommended for better behavior)
    echo Установка зависимостей...
    npm install
    if exist android (
      echo android\ уже присутствует, пропускаем prebuild
    ) else (
      where expo >nul 2>nul
      if %ERRORLEVEL% NEQ 0 (
        echo Expo CLI не найден. Установите: npm install -g expo-cli
        exit /b 1
      ) else (
        expo prebuild --platform android || echo prebuild failed
      )
    )
    cd android
    gradlew assembleRelease
    echo Готово. APK будет в android\app\build\outputs\apk\release\
