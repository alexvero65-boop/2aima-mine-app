## Инструкция по сборке и запуску (Android)

1. Установите Node.js (рекомендуется LTS) и yarn/npm.
2. Установите Expo CLI:
   ```
   npm install -g expo-cli
   ```
3. В корне проекта выполните:
   ```
   npm install
   ```
4. Для Android:
   - Установите Android Studio и Android SDK.
   - Запустите эмулятор или подключите устройство с включённым отладочным режимом.
   - Выполните:
     ```
     npm run android
     ```
5. Подписанный APK:
   - Для production-сборки используйте EAS Build (Expo Application Services) или React Native CLI + Android Studio (Gradle).
   - Если нужно — могу прислать шаги для EAS Build.

## Как найти реальные GATT UUID (если неизвестны)
1. Подключитесь к устройству через приложение nRF Connect (Android).
2. Откройте список сервисов и характеристик.
3. Сохраните UUID сервисов для батареи, скорости и команды замка.
4. Подставьте UUID в файлы screens/MainScreen.js.

