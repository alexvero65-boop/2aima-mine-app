import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity, PermissionsAndroid, Platform, Alert } from 'react-native';
import { BleManager } from 'react-native-ble-plx';

const manager = new BleManager();

export default function ConnectScreen({ navigation }) {
  const [devices, setDevices] = useState([]);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    return () => {
      manager.destroy();
    }
  }, []);

  async function startScan() {
    setDevices([]);
    if (Platform.OS === 'android') {
      const ok = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
      ]);
    }

    setScanning(true);
    manager.startDeviceScan(null, null, (error, device) => {
      if (error) {
        Alert.alert('Scan error', String(error));
        setScanning(false);
        return;
      }
      if (device && device.name && device.name.toLowerCase().includes('aima')) {
        setDevices(prev => {
          if (prev.find(d => d.id === device.id)) return prev;
          return [...prev, device];
        });
      }
    });

    // stop scan after 8s
    setTimeout(() => {
      manager.stopDeviceScan();
      setScanning(false);
    }, 8000);
  }

  async function connectTo(device) {
    try {
      const d = await device.connect();
      await d.discoverAllServicesAndCharacteristics();
      navigation.navigate('Main', { deviceId: d.id, deviceName: d.name || 'AIMA' });
    } catch (e) {
      Alert.alert('Connection error', String(e));
    }
  }

  return (
    <View style={{ flex:1, padding:16 }}>
      <Text style={{ fontSize:18, marginBottom:8 }}>Сканирование BLE-устройств (ищем AIMA)</Text>
      <Button title={scanning ? 'Сканирование...' : 'Сканировать'} onPress={startScan} />
      <FlatList
        data={devices}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <TouchableOpacity onPress={() => connectTo(item)} style={{ padding:12, borderBottomWidth:1 }}>
            <Text>{item.name} ({item.id})</Text>
          </TouchableOpacity>
        )}
        style={{ marginTop:12 }}
      />
    </View>
  );
}
