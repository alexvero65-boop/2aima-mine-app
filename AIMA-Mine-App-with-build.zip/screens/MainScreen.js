import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert } from 'react-native';
import { BleManager } from 'react-native-ble-plx';
import base64 from 'react-native-base64';

const manager = new BleManager();

// --- IMPORTANT: replace these UUIDs with real ones from AIMA Mine ---
const BATTERY_SERVICE_UUID = '0000180f-0000-1000-8000-00805f9b34fb';
const BATTERY_LEVEL_UUID = '00002a19-0000-1000-8000-00805f9b34fb';
const SPEED_SERVICE_UUID = '0000fff0-0000-1000-8000-00805f9b34fb'; // example vendor
const SPEED_CHAR_UUID = '0000fff1-0000-1000-8000-00805f9b34fb';
const LOCK_SERVICE_UUID = '0000fff2-0000-1000-8000-00805f9b34fb';
const LOCK_CHAR_UUID = '0000fff3-0000-1000-8000-00805f9b34fb';

export default function MainScreen({ route, navigation }) {
  const { deviceId, deviceName } = route.params;
  const [battery, setBattery] = useState(null);
  const [speed, setSpeed] = useState(null);
  const [connectedDevice, setConnectedDevice] = useState(null);
  const [locked, setLocked] = useState(false);

  useEffect(() => {
    let sub = null;
    async function setup() {
      try {
        const d = await manager.connectToDevice(deviceId);
        await d.discoverAllServicesAndCharacteristics();
        setConnectedDevice(d);

        // Read battery once
        try {
          const char = await d.readCharacteristicForService(BATTERY_SERVICE_UUID, BATTERY_LEVEL_UUID);
          const val = base64.decode(char.value);
          setBattery(val.charCodeAt(0));
        } catch(e) {
          console.warn('Battery read failed', e);
        }

        // Subscribe to speed characteristic if available
        sub = d.monitorCharacteristicForService(SPEED_SERVICE_UUID, SPEED_CHAR_UUID, (err, c) => {
          if (err) {
            console.warn('Speed monitor error', err);
            return;
          }
          if (c?.value) {
            const raw = base64.decode(c.value);
            // parse depending on device format; here's a simple number example:
            setSpeed(raw.charCodeAt(0));
          }
        });

      } catch (e) {
        Alert.alert('Connection error', String(e));
      }
    }
    setup();

    return () => {
      if (sub && sub.remove) sub.remove();
      // Do not destroy manager here to allow quick reconnection from Connect screen
    }
  }, [deviceId]);

  async function toggleLock() {
    if (!connectedDevice) return;
    try {
      // simple toggle: write 0x01 to lock, 0x00 to unlock (example)
      const value = locked ? 'AA==' : 'AQ=='; // base64 0xAA / 0x01 example (replace with real)
      await connectedDevice.writeCharacteristicWithResponseForService(LOCK_SERVICE_UUID, LOCK_CHAR_UUID, value);
      setLocked(!locked);
    } catch (e) {
      Alert.alert('Lock error', String(e));
    }
  }

  return (
    <View style={{ flex:1, padding:16 }}>
      <Text style={{ fontSize:18 }}>{deviceName}</Text>
      <Text>Battery: {battery !== null ? battery + '%' : '—'}</Text>
      <Text>Speed: {speed !== null ? speed + ' km/h' : '—'}</Text>
      <Button title={locked ? 'Разблокировать' : 'Заблокировать'} onPress={toggleLock} />
      <View style={{ height:12 }} />
      <Button title="Отключиться" onPress={async () => {
        if (connectedDevice) {
          await manager.cancelDeviceConnection(connectedDevice.id);
          navigation.navigate('Connect');
        }
      }} />
    </View>
  );
}
