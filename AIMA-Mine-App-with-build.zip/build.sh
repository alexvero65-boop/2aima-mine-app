#!/bin/bash
# build.sh - локальная сборка Android release (Unix: macOS/Linux)
# Требования:
#  - Node.js + npm/yarn
#  - Java JDK 11+
#  - Android SDK + ANDROID_HOME / ANDROID_SDK_ROOT set
#  - Android platform-tools, build-tools и платформы установлены
#  - expo-cli (optional) и expo prebuild (если проект managed -> bare)
#
set -e
echo "1) Установить зависимости..."
npm install
echo "2) (Опционально) если используете Expo managed, выполните 'expo prebuild' чтобы сгенерировать android/ директорию"
if [ -d "android" ]; then
  echo "android/ уже присутствует, пропускаем prebuild"
else
  if command -v expo >/dev/null 2>&1; then
    expo prebuild --platform android || true
  else
    echo "Expo CLI не найден. Установите: npm install -g expo-cli"
    exit 1
  fi
fi
echo "3) Сборка с помощью Gradle"
cd android
./gradlew assembleRelease
echo "Готово. APK будет в android/app/build/outputs/apk/release/"
